package U4ProgrammingA2;

public class Tournament extends Event { // This is where the tournaments are added onto the Menu Class 

    public static void createTournament() { // Creates a tournament
    }

    public static void tournamentResults() { 
    }
}
