package U4ProgrammingA2;

public class Main { // This is a main package where the code run as a program.

    private static int input;

    public static void main(String[] args) { 
        Menu.eventType();
    }
}
