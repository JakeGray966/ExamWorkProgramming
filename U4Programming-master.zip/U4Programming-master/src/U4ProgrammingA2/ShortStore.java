package U4ProgrammingA2;

// This is where the whole array is imported from
import java.util.ArrayList;
import java.util.List;

public class ShortStore {

    protected static List<String> listPlayer = new ArrayList(); // This is used as a list of stored players in the tournament

    protected static List<String> listTeam = new ArrayList(); // This is used as a list of stored teams in the tournament
}
