package U4ProgrammingA2;

public class Score { // This is the class which determines how many points a team is given if they win, lose or draw

    public void scoringSystem() {
    }
}
